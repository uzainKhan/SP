#!/bin/bash


r1()
{
echo "no arguments:"
exit 0
}

r2()
{
 echo "arguments greater then 6"
 exit 0
}

r3()
{
 declare -i num
declare -i var
var=$1
for i in `seq 1 10 `
do
num=$1\*$i
echo $num
done
 exit 0
}


r4()
{
 declare -i num
declare -i var
var=$1
var2=$3
if [ $2 = "-s" ]
then
for i in `seq $var2 10`
do
num=$1\*$i
echo $num
done
fi
}


r5()
{
 declare -i num
declare -i var
var=$1
var2=$3
if [ $2 = "-e" ]
then
for i in `seq 1 $var2`
do
num=$1\*$i
echo $num
done
fi
}


r6()
{
 declare -i num
declare -i var
var=$1
var2=$3
v=$5


for i in `seq $var2 $v`
do
num=$1\*$i
echo $num
done

}


r7()
{
 declare -i s
declare -i start
declare -i e
declare -i var
var=$1
e=$5
start=$3


while [ $e -ge $start ]

do
num=$var\*$e
echo $num
done

}




if [ $# -eq 0 ]
then 
r1

elif [ $# -gt 6 ]
then
r2

elif [ $# -eq 1 ]
then
r3 $1

elif [ $# -eq 3 ]
then
r4 $1 $2 $3

elif [ $# -eq 3 ]
then
r5 $1 $2 $3


elif [ $# -eq 5 ]
then
r6 $1 $2 $3 $4 $5

elif [ $# -eq 6 ]
then
r7 $1 $2 $3 $4 $5 $6

fi
