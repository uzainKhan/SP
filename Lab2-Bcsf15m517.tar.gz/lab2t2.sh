#!/bin/bash

id = `pidof $1`
#cd /proc/$d
echo "$id"
for pid in `pidof $1`
do
in=`cat /proc/$pid/status | grep -i name`
in1=`cat /proc/$pid/status | grep -i state`
in2=`cat /proc/$pid/status | grep -i pid`
in3=`cat /proc/$pid/status | grep -i ppid`
echo $in
echo $in1
echo $in2
echo $in3
done
