if [ $# = 0 ]
then 
echo "Please Enter the file"
exit 0
fi
if [ $# -gt 1 ]
then 
echo "Please Enter the only one file"
exit 0
fi
sort $1 | uniq -u | tee f2
echo ":New file : f2 has been created"
