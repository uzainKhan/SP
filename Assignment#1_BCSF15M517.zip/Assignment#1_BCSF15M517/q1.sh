cd $1 
for i in `ls $1`
do
 ext=${i##*.}
 if [ $ext != "$i" ]
 then  
  test -d $ext
  if [ $? = 1 ]
then
  mkdir $ext
fi
  mv $i $ext
 fi

done

ls $1

