touch odd
touch even


declare -i ctr

lines=`wc -l < $1`
ctr=1
c=0

while [ $lines -ne 0 ]
do

t=`sed "${ctr}q;d" $1`

if [ $c = 0 ]

then 
  
echo $t >> odd 
c=1

else 

echo $t >> even 
c=0


fi

ctr=`expr $ctr + 1`
lines=`expr $lines - 1`

done
