Is_Upper()
{
 echo "$1" | tr '[:upper:]' '[:lower:]'
}

Is_Root_User()
{
 if [ $EUID = 0 ]
 then
    echo "Script : '$0' is being executed by root usr  "
 else
    echo "Script : '$0' is not being executed by root usr  "    
 fi
}


Is_Root_User()
{
 if [ $EUID = 0 ]
 then
    echo "Script : '$0' is being executed by root usr  "
 else
    echo "Script : '$0' is not being executed by root usr  "    
 fi
}

Is_Exists()
{

name=$1

  for i in `cut -d: -f1 "/etc/passwd"`
do 

 if [ $i = $name ]

then
 echo "User : '$1' exists."
return 0

fi


done
 echo "User :'$1' does not exists."
   
 return 1

}


Is_Upper $1

Is_Root_User $0 $1

Is_Exists $2 





